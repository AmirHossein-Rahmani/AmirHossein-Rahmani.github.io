When updating the portfolio project
- Check if README.md in trickle/notes needs updates
- Update README.md if major features, structure, or design changes occur
- Keep README.md concise and focused on key information
- Document any significant new components or functionality